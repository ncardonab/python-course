def func_3():
    print('func_1')

def func_4():
    print('func_2')