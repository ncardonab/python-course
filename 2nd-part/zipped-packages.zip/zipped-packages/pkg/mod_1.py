def func_1():
    print('func_1')

def func_2():
    print('func_2')